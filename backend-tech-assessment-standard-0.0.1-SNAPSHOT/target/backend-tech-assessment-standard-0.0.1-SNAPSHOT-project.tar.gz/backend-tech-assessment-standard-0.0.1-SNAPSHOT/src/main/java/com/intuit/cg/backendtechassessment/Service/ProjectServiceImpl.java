package com.intuit.cg.backendtechassessment.Service;

import com.intuit.cg.backendtechassessment.Entity.Project;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicLong;
import java.util.List;
import java.util.ArrayList;

@Service("projectService")
public class ProjectServiceImpl implements ProjectService {

    private static final AtomicLong counter = new AtomicLong();
    private List<Project> projects = new ArrayList<Project>();

    public Project findByProjId(long projId) {
        for (Project project : projects) {
            if (project.getProjId() == projId) {
                return project;
            }
        }
        return null;
    }

    public List<Project> findByProjName(String projName) {
        List<Project> tempProjects = null;
        if (projects != null) {
            tempProjects = new ArrayList<Project>();
            for (Project project : projects) {
                if (project.getProjName().equalsIgnoreCase(projName)) {
                    tempProjects.add(project);
                }
            }
        }
        return tempProjects;
    }

    public void createProject(Project project) {
        project.setProjId(counter.incrementAndGet());
        projects.add(project);
    }

    public void updateProject(Project project) {
        int index = projects.indexOf(project);
        projects.set(index, project);
    }

    public void deleteByProjId(long projId) {
        for (Iterator<Project> iterator = projects.iterator(); ((Iterator) iterator).hasNext(); ) {
            Project project = (Project) ((Iterator) iterator).next();
            if (project.getProjId() == projId) {
                iterator.remove();
            }
        }
    }

    public List<Project> getAllProjects() {
        return projects;
    }

    public boolean isProjectExists(Project project) {
        List<Project> tempProjects = findByProjName(project.getProjName());
        if (tempProjects == null) {
            return false;
        }
        for (Project proj : tempProjects) {
            if (proj.getSellerId().equalsIgnoreCase(project.getSellerId())
                    || proj.getMaxBidDateTime().isAfter(OffsetDateTime.now())) {
                return true;
            }
        }
        return false;
    }
}
