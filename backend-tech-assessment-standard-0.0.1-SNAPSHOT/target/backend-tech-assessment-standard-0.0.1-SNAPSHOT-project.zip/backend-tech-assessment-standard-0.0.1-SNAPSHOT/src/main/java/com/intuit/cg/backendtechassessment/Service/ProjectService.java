package com.intuit.cg.backendtechassessment.Service;

import com.intuit.cg.backendtechassessment.Entity.Project;

import java.util.List;

public interface ProjectService {
    Project findByProjId(long projId);
    List<Project> findByProjName(String projName);
    void createProject(Project project);
    void updateProject(Project project);
    void deleteByProjId(long projId);
    List<Project> getAllProjects();
    boolean isProjectExists(Project project);
}
